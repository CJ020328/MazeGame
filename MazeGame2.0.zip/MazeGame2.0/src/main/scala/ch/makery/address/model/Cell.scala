package ch.makery.address.model

class Cell(val x: Int, val y: Int, var isWall: Boolean, val maze: Maze) {
  def neighbor(dx: Int, dy: Int): Option[Cell] = {
    maze.cellAt(x + dx, y + dy)
  }
}