package ch.makery.address.model

import scala.util.Random
import javafx.scene.image.{Image, ImageView, WritableImage}
import scalafx.Includes.jfxImage2sfx
import scalafx.geometry.Rectangle2D

import java.io.{FileOutputStream, ObjectOutputStream}
import scala.util.control.Breaks.break



class Player(var currentCell: Cell, var name: String, var health: Int, var mp: Int, var attackPower: Int, var defense: Int, var experiencePoints: Int) {

  var maxHealth: Int = health
  var maxMp: Int = mp
  var baseAttackPower: Int = attackPower
  var inventory: Inventory = new Inventory
  var equippedSword: Option[Sword] = None
  var equippedArmor: Option[Armor] = None
  var equippedRing: Option[Ring] = None
  var currentFrame = Map("down" -> 0, "left" -> 0, "right" -> 0, "up" -> 0)
  var level: Int = 1
  var experienceThreshold: Int = 80
  var didLevelUp: Boolean = false
  var specialDefenseActive: Boolean = false
  var focusTurnsLeft: Int = 0
  var veryFocusTurnsLeft: Int = 0
  var cannotMove: Boolean = false
  var justAppliedFocus: Boolean = false
  var justAppliedVeryFocus: Boolean = false
  var shieldTurnsLeft: Int = 0
  var lastLevel: Int = 1



  var playerStaticImage = new Image(getClass.getResource("/image/player.png").toExternalForm())

  val spriteSheetImage = new Image(getClass.getResource("/image/playerSpriteSheet.png").toExternalForm())
  val directions = List("down", "left", "right", "up")
  val framesPerDirection = 3 // Change this to match your sprite sheet
  val frameWidth = 32 // Change these to match the size of your frames
  val frameHeight = 32
  var poisonTurnsLeft: Int = 0
  var lichsCurseTurnsLeft: Int = 0
  var originalAttackPower: Int = attackPower
  var originalDefense: Int = defense

  var playerMazeImage = new WritableImage(frameWidth, frameHeight)

  val playerImageView = new ImageView(spriteSheetImage) {
    setFitWidth(frameWidth)
    setFitHeight(frameHeight)
  }

  playerImageView.setViewport(new Rectangle2D(0, 0, frameWidth, frameHeight))

  val specialMoves: List[SpecialMove] = List(
    SpecialMove("Heavy Attack", 1.5, 25, "A powerful attack that deals 1.5x damage.", DamageMove,1),
    SpecialMove("Last Stand", 0, 20, "Survive the next attack with 1 HP.", DefenseMove,6) ,
    SpecialMove("Poison Sword", 1, 25, "A venomous strike that poisons the enemy for 3 turns.", PoisonMove,2),
    SpecialMove("Lightning Strike", 1.3, 30, "Inflicts electrical damage and has a chance to paralyze the enemy.", ImmobilizeMove,4),
    SpecialMove("Focus", 0, 10, "Increases the player's attack power for the next 3 turns.", FocusBuffMove,3),
    SpecialMove("Very Focus", 0, 30, "Cannot move for one round, Increases the player's attack power for 2.0 for the next round.", VeryFocusBuffMove,5),
    SpecialMove("Meteor Strike", 2.5, 50, "Calls forth a meteor from the heavens to deal a devastating blow to the enemy. Deals 2.5x damage but makes the player immobile for the next round.", DelayedMove,7) ,
    SpecialMove("Mystic Shield", 0, 30, "Summons a mystical barrier that reduces all incoming damage by 50% for the next 3 turns.", DefenseBuffMove,6)
  )

  def setSprite(direction: String): Unit = {
    val i = directions.indexOf(direction)
    val frame = currentFrame(direction)
    val x = frame * frameWidth
    val y = i * frameHeight
    playerImageView.setViewport(new Rectangle2D(x, y, frameWidth, frameHeight))
    playerMazeImage = playerImageView.snapshot(null, null) // update player's maze image

    currentFrame = currentFrame.updated(direction, (frame + 1) % framesPerDirection)
  }

  inventory.addItem(new Sword("Basic Sword", 5,  "A basic sword with moderate attack power","Attack +5", 2,"/image/item/sword2.png"))
  inventory.addItem(new Armor("Basic Armor", 5, "A basic armor with moderate defense", "Defense +5",1,"/image/item/armor3.png"))
  inventory.addItem(new Ring("Basic Ring", 5, "A basic ring that increases health", "Health + 5",1, "/image/item/ring1.png"))
  inventory.addItem(new RedPotion(3))
  inventory.addItem(new BluePotion(3))
  def move(dx: Int, dy: Int): Unit = {
    val newCell = currentCell.neighbor(dx, dy)
    if (newCell.isDefined && !newCell.get.isWall) {
      currentCell = newCell.get
    }
  }

  def usePotion(potion: Potion): String = {
    potion match {
      case _: RedPotion =>
        if (health >= maxHealth) {
          "Your HP is full, no need to use the potion!"
        } else {
          val healingAmount = Math.min(potion.healingAmount, maxHealth - health)
          health += healingAmount
          potion.quantity -= 1
          if (potion.quantity == 0) {
            inventory.removeItem(potion)
          }
          s"Used ${potion.name}. Healed for $healingAmount HP."
        }
      case _: BluePotion =>
        if (mp >= maxMp) {
          "Your MP is full, no need to use the potion!"
        } else {
          val manaAmount = Math.min(potion.manaAmount, maxMp - mp)
          mp += manaAmount
          potion.quantity -= 1
          if (potion.quantity == 0) {
            inventory.removeItem(potion)
          }
          s"Used ${potion.name}. Recovered $manaAmount MP."
        }
      case _ =>
        "Invalid potion type!"
    }
  }


  def equipSword(sword: Sword): Boolean = {
    if (equippedSword.isDefined) {
      return false
    }

    equippedSword = Some(sword)
    attackPower += sword.attackPower
    sword.quantity -= 1

    if (sword.quantity == 0) {
      inventory.removeItem(sword)
    }

    true
  }

  def equipArmor(armor: Armor): Boolean = {
    if (equippedArmor.isDefined) {
      return false
    }

    equippedArmor = Some(armor)
    defense += armor.defense
    armor.quantity -= 1

    if (armor.quantity == 0) {
      inventory.removeItem(armor)
    }

    true
  }

  def equipRing(ring: Ring): Boolean = {
    if (equippedRing.isDefined) {
      return false
    }

    equippedRing = Some(ring)
    health += ring.health
    ring.quantity -= 1

    if (ring.quantity == 0) {
      inventory.removeItem(ring)
    }

    true
  }

  def unequipSword(): Unit = {
    if (equippedSword.isDefined) {
      attackPower -= equippedSword.get.attackPower
      inventory.addItem(new Armor(equippedSword.get.name, equippedSword.get.attackPower, equippedSword.get.description, equippedSword.get.status, 1,equippedSword.get.imagePath))
      equippedSword = None
    }
  }



  def unequipArmor(): Unit = {
    if (equippedArmor.isDefined) {
      defense -= equippedArmor.get.defense
      inventory.addItem(new Armor(equippedArmor.get.name, equippedArmor.get.defense, equippedArmor.get.description, equippedArmor.get.status, 1,equippedArmor.get.imagePath))
      equippedArmor = None
    }
  }

  def unequipRing(): Unit = {
    if (equippedRing.isDefined) {
      health -= equippedRing.get.health
      inventory.addItem(new Ring(equippedRing.get.name, equippedRing.get.health, equippedRing.get.description, equippedRing.get.status, 1,equippedRing.get.imagePath))
      equippedRing = None
    }
  }

  def applyPoisonEffect(): Unit = {
    if (poisonTurnsLeft > 0) {
      val poisonDamage = (maxHealth * 0.10).toInt
      health -= poisonDamage
      if (health < 0) health = 0
      poisonTurnsLeft -= 1
    }
  }


  def reset(startCell: Cell): Unit = {
    currentCell = startCell
  }

  def attack(enemy: Enemy): Int = {
    val baseMultiplier = if (focusTurnsLeft > 0) 1.25 else 1.0
    val veryFocusMultiplier = if (veryFocusTurnsLeft > 0) 2.0 else 1.0

    val enemyDamageReduction = if (enemy.damageReductionTurnsLeft > 0) enemy.damageReductionMultiplier else 1.0

    val effectiveAttackPower = attackPower * baseMultiplier * veryFocusMultiplier * enemyDamageReduction
    val damage = Math.max(0, effectiveAttackPower.toInt - enemy.defense)

    enemy.health -= damage
    println(s"${name} attacks! ${enemy.species.name} takes $damage damage.")
    if (enemy.health <= 0) {
      enemy.health = 0
    }
    damage
  }


  def useSpecialMove(move: SpecialMove, enemy: Enemy): String = {
    if (mp < move.mpCost) {
      return "Not enough MP!"
    }
    mp -= move.mpCost

    move.moveType match {
      case DamageMove =>
        val rawDamage = (attackPower * move.damageMultiplier).toInt
        val damage = Math.max(0, rawDamage - enemy.defense)
        enemy.health -= damage
        if (enemy.health < 0) enemy.health = 0
        s"Used ${move.name} and dealt $damage damage!"

      case DefenseMove =>
        specialDefenseActive = true
        s"Used ${move.name}. You will survive the next attack!"

      case PoisonMove =>
        val rawDamage = attackPower
        val damage = Math.max(0, rawDamage - enemy.defense)
        enemy.health -= damage
        enemy.poisonTurnsLeft = 3
        if (enemy.health < 0) enemy.health = 0
        s"Used ${move.name} and dealt $damage damage! ${enemy.species.name} is now poisoned!"

      case ImmobilizeMove =>
        val rawDamage = (attackPower * move.damageMultiplier).toInt
        val damage = Math.max(0, rawDamage - enemy.defense)
        enemy.health -= damage
        if (enemy.health < 0) enemy.health = 0
        if (new Random().nextDouble() < 0.5) enemy.isParalyzed = true
        s"Used ${move.name} and dealt $damage damage! ${if (enemy.isParalyzed) s"${enemy.species.name} is paralyzed!" else ""}"

      case FocusBuffMove =>
        if (focusTurnsLeft == 0) {
          baseAttackPower = attackPower
        }
        focusTurnsLeft = 3
        justAppliedFocus = true
        s"Used ${move.name}. Attack power increased for the next 3 turns!"

      case VeryFocusBuffMove =>
        if (veryFocusTurnsLeft == 0) {
          baseAttackPower = attackPower
        }
        veryFocusTurnsLeft = 1
        justAppliedVeryFocus = true
        s"Used ${move.name}. You can't move this turn, but attack power will be doubled next turn!"

      case DelayedMove =>
        val rawDamage = (attackPower * move.damageMultiplier).toInt
        val damage = Math.max(0, rawDamage - enemy.defense)
        enemy.health -= damage
        if (enemy.health < 0) enemy.health = 0
        cannotMove = true
        s"Used ${move.name} and dealt $damage damage! You feel the aftermath of the powerful strike and can't move next turn."

      case DefenseBuffMove =>
        shieldTurnsLeft = 3
        s"Used ${move.name}. Incoming damage reduced by 50% for the next 3 turns!"
    }
  }

  def decrementBuffCounters(): Unit = {
    if (!justAppliedFocus && focusTurnsLeft > 0) {
      focusTurnsLeft -= 1
      if (focusTurnsLeft == 0) {
        attackPower = baseAttackPower
      }
    }
    if (!justAppliedVeryFocus && veryFocusTurnsLeft > 0) {
      veryFocusTurnsLeft -= 1
      if (veryFocusTurnsLeft == 0) {
        attackPower = baseAttackPower
      }
    }


    if (shieldTurnsLeft > 0) {
      shieldTurnsLeft -= 1
      println(s"Shield turns left: $shieldTurnsLeft")
    }



    // Reset the flags at the end
    justAppliedFocus = false
    justAppliedVeryFocus = false
  }

  def applyLichsCurseEffect(): Unit = {
    if (lichsCurseTurnsLeft > 0) {
      lichsCurseTurnsLeft -= 1

      if (lichsCurseTurnsLeft == 0) {
        attackPower = originalAttackPower
        defense = originalDefense
      }
    }
  }

  def endOfTurnEffects(): Unit = {
    applyPoisonEffect()
    decrementBuffCounters()
    applyLichsCurseEffect()
  }

  def resetFocusAfterBattle(): Unit = {
    focusTurnsLeft = 0
    veryFocusTurnsLeft = 0
    cannotMove = false
  }

  def gainExperience(points: Int): Unit = {
    experiencePoints += points
    println(s"You gained $points experience points!")

    val initialLevel = level


    while (experiencePoints >= experienceThreshold) {
      experiencePoints -= experienceThreshold

      levelUp()

      println(s"Leveled up! Remaining XP: $experiencePoints, XP Needed for Next Level: $experienceThreshold")
    }

    if (initialLevel != level) {
      lastLevel = initialLevel
    }
  }


  def levelUp(): Unit = {
    level += 1
    health = (health * 1.15).toInt
    maxHealth = (maxHealth * 1.15).toInt
    maxMp = (maxMp * 1.05).toInt
    attackPower = (attackPower * 1.15).toInt
    val defenseIncrement = (defense * 1.15).toInt - defense
    defense += Math.max(defenseIncrement, 1)

    health = maxHealth
    mp = maxMp


    experienceThreshold = (experienceThreshold * 1.15).toInt
    didLevelUp = true
    println(s"Leveling up? true")
  }


  def tryToEscape(): Boolean = {
    val random = new Random()
    random.nextDouble() < 0.5
  }

}
