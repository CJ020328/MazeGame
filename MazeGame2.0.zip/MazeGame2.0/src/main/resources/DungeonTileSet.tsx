<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tileSet_Duengeon" tilewidth="32" tileheight="32" tilecount="44" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="32" source="image/tileSet/1.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="32" source="image/tileSet/2.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="32" source="image/tileSet/3.png"/>
 </tile>
 <tile id="3">
  <image width="32" height="32" source="image/tileSet/4.png"/>
 </tile>
 <tile id="4">
  <image width="32" height="32" source="image/tileSet/5.png"/>
 </tile>
 <tile id="5">
  <image width="32" height="32" source="image/tileSet/6.png"/>
 </tile>
 <tile id="6">
  <image width="32" height="32" source="image/tileSet/7.png"/>
 </tile>
 <tile id="7">
  <image width="32" height="32" source="image/tileSet/8.png"/>
 </tile>
 <tile id="8">
  <image width="32" height="32" source="image/tileSet/9.png"/>
 </tile>
 <tile id="9" type="wall">
  <image width="32" height="32" source="image/tileSet/10.png"/>
 </tile>
 <tile id="10" type="wall">
  <image width="32" height="32" source="image/tileSet/11.png"/>
 </tile>
 <tile id="11" type="wall">
  <image width="32" height="32" source="image/tileSet/12.png"/>
 </tile>
 <tile id="12" type="wall">
  <image width="32" height="32" source="image/tileSet/13.png"/>
 </tile>
 <tile id="13" type="wall">
  <image width="32" height="32" source="image/tileSet/14.png"/>
 </tile>
 <tile id="14" type="wall">
  <image width="32" height="32" source="image/tileSet/15.png"/>
 </tile>
 <tile id="15" type="wall">
  <image width="32" height="32" source="image/tileSet/16.png"/>
 </tile>
 <tile id="16" type="wall">
  <image width="32" height="32" source="image/tileSet/17.png"/>
 </tile>
 <tile id="17" type="wall">
  <image width="32" height="32" source="image/tileSet/18.png"/>
 </tile>
 <tile id="18" type="wall">
  <image width="32" height="32" source="image/tileSet/19.png"/>
 </tile>
 <tile id="19" type="wall">
  <image width="32" height="32" source="image/tileSet/20.png"/>
 </tile>
 <tile id="20" type="wall">
  <image width="32" height="32" source="image/tileSet/21.png"/>
 </tile>
 <tile id="21" type="wall">
  <image width="32" height="32" source="image/tileSet/22.png"/>
 </tile>
 <tile id="22" type="wall">
  <image width="32" height="32" source="image/tileSet/23.png"/>
 </tile>
 <tile id="23" type="wall">
  <image width="32" height="32" source="image/tileSet/24.png"/>
 </tile>
 <tile id="24" type="wall">
  <image width="32" height="32" source="image/tileSet/25.png"/>
 </tile>
 <tile id="25" type="wall">
  <image width="32" height="32" source="image/tileSet/26.png"/>
 </tile>
 <tile id="26" type="wall">
  <image width="32" height="32" source="image/tileSet/27.png"/>
 </tile>
 <tile id="27" type="wall">
  <image width="32" height="32" source="image/tileSet/28.png"/>
 </tile>
 <tile id="28" type="wall">
  <image width="32" height="32" source="image/tileSet/29.png"/>
 </tile>
 <tile id="29" type="wall">
  <image width="32" height="32" source="image/tileSet/30.png"/>
 </tile>
 <tile id="30" type="wall">
  <image width="32" height="32" source="image/tileSet/31.png"/>
 </tile>
 <tile id="31">
  <image width="32" height="32" source="image/tileSet/32.png"/>
 </tile>
 <tile id="32">
  <image width="32" height="32" source="image/tileSet/33.png"/>
 </tile>
 <tile id="33" type="door2">
  <image width="32" height="32" source="image/tileSet/34.png"/>
 </tile>
 <tile id="34" type="door4">
  <image width="32" height="32" source="image/tileSet/35.png"/>
 </tile>
 <tile id="35" type="door1">
  <image width="32" height="32" source="image/tileSet/36.png"/>
 </tile>
 <tile id="36" type="wall">
  <image width="32" height="32" source="image/tileSet/37.png"/>
 </tile>
 <tile id="37">
  <image width="32" height="32" source="image/tileSet/38.png"/>
 </tile>
 <tile id="38" type="recover">
  <image width="32" height="32" source="door0.png"/>
 </tile>
 <tile id="39" type="door0">
  <image width="32" height="32" source="door0.png"/>
 </tile>
 <tile id="40">
  <image width="32" height="32" source="door3.png"/>
 </tile>
 <tile id="41" type="door5">
  <image width="32" height="32" source="door3.png"/>
 </tile>
 <tile id="42">
  <image width="32" height="32" source="door 4.png"/>
 </tile>
 <tile id="43" type="door3">
  <image width="32" height="32" source="door 4.png"/>
 </tile>
</tileset>
