package ch.makery.address.controller

import ch.makery.address.model._
import javafx.fxml.FXML
import javafx.scene.control.{Alert, Button, ListCell, ListView, ProgressBar, Tooltip}
import javafx.scene.text.Text
import javafx.collections.FXCollections
import javafx.collections.ObservableList
import javafx.scene.control.Alert.AlertType
import javafx.scene.image.ImageView
import javafx.util.Callback
import scalafx.scene.input.{KeyCode, KeyEvent}
import javafx.scene.shape.Rectangle
import javafx.scene.paint.Color
import scalafx.scene.input.MouseEvent
import javafx.scene.input.MouseButton
import javafx.scene.layout.VBox
import scalafx.scene.control.Label
import javafx.scene.layout.StackPane
import scalafx.animation.PauseTransition
import scalafx.scene.image.Image
import scalafx.util.Duration

class InventoryController {
  var gameController: GameController = _
  var battleController: BattleController =_
  val EQUIPPED_COLOR: Color = Color.BLACK

  @FXML
  private var inventoryList: ListView[Item] = _
  @FXML
  private var equipButton: Button = _
  @FXML
  private var playerStats: Text = _
  @FXML
  private var swordPane: javafx.scene.layout.StackPane = _
  @FXML
  private var armorPane: javafx.scene.layout.StackPane = _
  @FXML
  private var ringPane: javafx.scene.layout.StackPane = _
  @FXML
  private var playerImageView: ImageView = _
  @FXML
  private var playerLevel: Text = _
  @FXML
  private var playerHP: Text = _
  @FXML
  private var playerMP: Text = _
  @FXML
  private var playerAttackPower: Text = _
  @FXML
  private var playerDefense: Text = _
  @FXML
  private var experienceBar: ProgressBar = _
  @FXML
  private var hpBar: javafx.scene.control.ProgressBar = _
  @FXML
  private var mpBar: javafx.scene.control.ProgressBar = _


  @FXML
  def handleKeyPress(ke: KeyEvent): Unit = {
    ke.code match {
      case KeyCode.E => if (gameController.inBattle) {
        gameController.displayBattleView()
      } else {
        gameController.exitInventoryView()
      }
      case _ =>
    }
  }

  @FXML
  def handleSwordPaneClick(event: javafx.scene.input.MouseEvent): Unit = {
    if (event.getClickCount == 2 && gameController.player.equippedSword.isDefined) {
      swordPane.getChildren.clear()
      val rectangle = new Rectangle(50, 50, Color.GRAY)
      swordPane.getChildren.add(rectangle)
      Tooltip.uninstall(swordPane, null)
      gameController.player.unequipSword()
      updateInventoryList()
      updatePlayerStats()
    }
  }

  @FXML
  def handleArmorPaneClick(event: javafx.scene.input.MouseEvent): Unit = {
    if (event.getClickCount == 2 && gameController.player.equippedArmor.isDefined) {
      armorPane.getChildren.clear()
      val rectangle = new Rectangle(50, 50, Color.GRAY)
      armorPane.getChildren.add(rectangle)
      Tooltip.uninstall(armorPane, null)
      gameController.player.unequipArmor()
      updateInventoryList()
      updatePlayerStats()
    }
  }

  @FXML
  def handleRingPaneClick(event: javafx.scene.input.MouseEvent): Unit = {
    if (event.getClickCount == 2 && gameController.player.equippedRing.isDefined) {
      ringPane.getChildren.clear()
      val rectangle = new Rectangle(50, 50, Color.GRAY)
      ringPane.getChildren.add(rectangle)
      Tooltip.uninstall(ringPane, null)
      gameController.player.unequipRing()
      updateInventoryList()
      updatePlayerStats()
    }
  }


  def setGameController(gameController: GameController): Unit = {
    this.gameController = gameController
    playerImageView.setImage(gameController.player.playerStaticImage)
    updateInventoryList()
    updatePlayerStats()
  }


  def updateInventoryList(): Unit = {
    if (gameController != null && gameController.player != null && gameController.player.inventory != null) {
      val observableList: ObservableList[Item] = FXCollections.observableArrayList()
      observableList.addAll(gameController.player.inventory.items: _*)
      inventoryList.setItems(observableList)

      inventoryList.setCellFactory(new Callback[ListView[Item], ListCell[Item]]() {
        override def call(param: ListView[Item]): ListCell[Item] = new ListCell[Item] {
          override def updateItem(item: Item, empty: Boolean): Unit = {
            super.updateItem(item, empty)
            if (item != null) {
              val itemImage = new ImageView(new Image(item.imagePath))
              itemImage.setFitWidth(50)
              itemImage.setFitHeight(50)
              val itemName = new Label(item.name)
              val itemDescription = new Label(item.description)
              val itemStatus = new Label(item.status)
              val itemQuantity = new Label("Quantity: " + item.quantity.toString)
              val itemBox = new VBox(itemImage, itemName, itemDescription, itemStatus, itemQuantity) // Add itemImage to the VBox
              setGraphic(itemBox)
            } else {
              setGraphic(null)
            }
          }
        }
      })

      // Handle double-click events on the ListView
      inventoryList.setOnMouseClicked(event => {
        if (gameController.inBattle) {
          val selectedItem = inventoryList.getSelectionModel.getSelectedItem
          selectedItem match {
            case potion: Potion =>
              val result = gameController.player.usePotion(potion)
              // Display the message to the user
              val alert = new Alert(AlertType.INFORMATION)
              alert.setTitle("Information")
              alert.setHeaderText(null)
              alert.setContentText(result)
              alert.showAndWait()
              updateInventoryList()
              updatePlayerStats()
              if (result.startsWith("Used")) {
                gameController.displayBattleView()
                gameController.battleController.updateBattleView(result, 0)
                val pause = new PauseTransition(Duration(3000)) // 2 seconds delay
                pause.setOnFinished(_ => gameController.battleController.enemyTurn())
                pause.play()
              }
            case _ =>
              val alert = new Alert(Alert.AlertType.WARNING)
              alert.setTitle("Battle Mode")
              alert.setHeaderText(null)
              alert.setContentText("You are in a battle now, you can only use potions!")
              alert.showAndWait()
          }
        } else {
        if (event.getClickCount == 2 && (!inventoryList.getSelectionModel().isEmpty)) {
          val selectedItem = inventoryList.getSelectionModel.getSelectedItem
          selectedItem match {
            case sword: Sword =>
              if (gameController.player.equipSword(sword)) {
                val swordImage = new ImageView(new Image(sword.imagePath))
                swordImage.setFitWidth(50)
                swordImage.setFitHeight(50)
                val tooltip = new Tooltip(sword.status)
                Tooltip.install(swordImage, tooltip)
                swordPane.getChildren.add(swordImage)
                updateInventoryList()
                updatePlayerStats()
              }
            case armor: Armor =>
              if (gameController.player.equipArmor(armor)) {
                val armorImage = new ImageView(new Image(armor.imagePath))
                armorImage.setFitWidth(50)
                armorImage.setFitHeight(50)
                val tooltip = new Tooltip(armor.status)
                Tooltip.install(armorImage, tooltip)
                armorPane.getChildren.add(armorImage)
                updateInventoryList()
                updatePlayerStats()
              }
            case ring: Ring =>
              if (gameController.player.equipRing(ring)) {
                val ringImage = new ImageView(new Image(ring.imagePath))
                ringImage.setFitWidth(50)
                ringImage.setFitHeight(50)
                val tooltip = new Tooltip(ring.status)
                Tooltip.install(ringImage, tooltip)
                ringPane.getChildren.add(ringImage)
                updateInventoryList()
                updatePlayerStats()
              }

            case potion: Potion =>
              val message = gameController.player.usePotion(potion)
              // Display the message to the user
              val alert = new Alert(AlertType.INFORMATION)
              alert.setTitle("Information")
              alert.setHeaderText(null)
              alert.setContentText(message)
              alert.showAndWait()
              updateInventoryList()
              updatePlayerStats()

            case _ =>
          }
        }
        }
      })
    }
  }


  def updatePlayerStats(): Unit = {
    playerImageView.setFitWidth(100)
    playerImageView.setFitHeight(100)
    if (gameController != null && gameController.player != null) {
      val player = gameController.player
      playerLevel.setText(s"Level: ${player.level}")
      experienceBar.setProgress(player.experiencePoints.toDouble / player.experienceThreshold.toDouble)
      hpBar.setProgress(player.health.toDouble / player.maxHealth.toDouble)
      playerHP.setText(s"HP: ${player.health}/${player.maxHealth}")
      mpBar.setProgress(player.mp.toDouble / player.maxMp.toDouble)
      playerMP.setText(s"MP: ${player.mp}/${player.maxMp}")
      playerAttackPower.setText(s"Attack Power: ${player.attackPower}")
      playerDefense.setText(s"Defense: ${player.defense}")
    }
  }

  @FXML
  def handleEquip(): Unit = {
    if (inventoryList != null) {
      val selectedItem = inventoryList.getSelectionModel.getSelectedItem
      selectedItem match {
        case sword: Sword => gameController.player.equipSword(sword)
        case armor: Armor => gameController.player.equipArmor(armor)
        case ring: Ring => gameController.player.equipRing(ring)
        case _ =>
      }
      updateInventoryList()
      updatePlayerStats()
    }
  }
}
