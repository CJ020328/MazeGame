package ch.makery.address.model

import scalafx.scene.paint.Color

trait Consumable {
  def consume: String
}


abstract class Item(val name: String, val description: String, val status: String, var quantity: Int, val imagePath: String)

class Sword(_name: String, val attackPower: Int, _description: String, _status: String, _quantity: Int, _imagePath: String)
  extends Item(_name, _description, _status, _quantity, _imagePath)

class Armor(_name: String, val defense: Int, _description: String, _status: String, _quantity: Int, _imagePath: String)
  extends Item(_name, _description, _status, _quantity, _imagePath)

class Ring(_name: String, val health: Int, _description: String, _status: String, _quantity: Int, _imagePath: String)
  extends Item(_name, _description, _status, _quantity, _imagePath)

class Potion(_name: String, val healingAmount: Int, val manaAmount: Int, _description: String, _status: String, _quantity: Int, _imagePath: String)
  extends Item(_name, _description, _status, _quantity, _imagePath) with Consumable {

  override def consume: String = {
    if (healingAmount > 0 && manaAmount > 0) {
      s"Consumed ${_name}. Healed for $healingAmount HP and recovered $manaAmount MP."
    } else if (healingAmount > 0) {
      s"Consumed ${_name}. Healed for $healingAmount HP."
    } else {
      s"Consumed ${_name}. Recovered $manaAmount MP."
    }
  }
}

class RedPotion(quantity: Int)
  extends Potion("Red Potion", 50,0, "Heals for 50 HP", "A Normal Potion that can heal the user", quantity, "/image/item/redpotion.png")

class BluePotion(quantity: Int)
  extends Potion("Blue Potion", 0, 50, "Recovers for 50 MP", "Available", quantity, "/image/item/bluepotion.png")
