package ch.makery.address.model

import java.io.InputStream
import scala.util.Random
import scala.xml._

object MazeEnemyPools {
  val maze1Pool = List(
    (EnemySpeciesList.Royal_Scarad, 1 to 3),
    (EnemySpeciesList.Sand_Ghoul, 1 to 3),
    (EnemySpeciesList.Rotting_Archer, 1 to 3),
  )

  val maze2Pool = List(
    (EnemySpeciesList.Royal_Scarad, 3 to 6),
    (EnemySpeciesList.Sand_Ghoul, 3 to 6),
    (EnemySpeciesList.Rotting_Archer, 3 to 6),
    (EnemySpeciesList.Grave_Revenant, 3 to 6),
    (EnemySpeciesList.Ancient_Fighter, 3 to 6),
    (EnemySpeciesList.Skittering_Hand, 3 to 6)
  )

  val maze3Pool = List(
    (EnemySpeciesList.Royal_Scarad, 6 to 9),
    (EnemySpeciesList.Sand_Ghoul, 6 to 9),
    (EnemySpeciesList.Rotting_Archer, 6 to 9),
    (EnemySpeciesList.Grave_Revenant, 6 to 9),
    (EnemySpeciesList.Ancient_Fighter, 6 to 9),
    (EnemySpeciesList.Skittering_Hand, 6 to 9)
  )

}

class Maze(val width: Int, val height: Int, tmxFilePath: String) extends Serializable {

  var cells: Array[Array[Cell]] = Array.tabulate(width, height) { (x, y) =>
    new Cell(x, y, isWall = false, this)
  }


  var goal: Cell = cells(width - 2)(height - 2)
  var start: Cell = cells(1)(5)
  var enemies: Map[Cell, Enemy] = Map.empty
  val (layer1, layer2) = parseTMX(tmxFilePath)

  val tileMap = (0 to 38).map { i =>
    i -> s"/image/tileSet/$i.png"
  }.toMap + (39 -> "/image/tileSet/35.png") + (41 -> "/image/tileSet/34.png") + (43 -> "/image/tileSet/33.png")

  val tileTypes = parseTSX("/DungeonTileSet.tsx")


  def generate(): Unit = {
    for (x <- 0 until width; y <- 0 until height) {
      val tileType1 = tileTypes.getOrElse(layer1(y)(x), "")
      val tileType2 = tileTypes.getOrElse(layer2(y)(x), "")
      if (tileType1 == "wall" || tileType2 == "wall") {
        cells(x)(y).isWall = true
      }

      layer2(y)(x) match {
        case id if tileTypes.getOrElse(id, "") == "goal" => goal = cells(x)(y)
        case _ =>
      }
    }
  }

  def parseTMX(filePath: String): (Array[Array[Int]], Array[Array[Int]]) = {
    // Load the XML from the TMX file
    val stream: InputStream = getClass.getResourceAsStream(filePath)
    val xml = XML.load(stream)

    // Extract data for the two layers
    val layers = (xml \\ "layer" \\ "data").map(_.text.trim)

    // Assuming you have two layers, assign them to variables
    val layer1Data = layers(0).split(",").map(_.trim.toInt)
    val layer2Data = layers(1).split(",").map(_.trim.toInt)

    // Extract the maze dimensions
    val width = (xml \\ "map" \ "@width").text.toInt
    val height = (xml \\ "map" \ "@height").text.toInt

    // Convert 1D arrays to 2D arrays
    val layer1Matrix = Array.ofDim[Int](height, width)
    val layer2Matrix = Array.ofDim[Int](height, width)

    for (i <- 0 until height; j <- 0 until width) {
      layer1Matrix(i)(j) = layer1Data(i * width + j)
      layer2Matrix(i)(j) = layer2Data(i * width + j)
    }

    (layer1Matrix, layer2Matrix)
  }

  def parseTSX(filePath: String): Map[Int, String] = {
    // Load the XML from the TSX file
    val stream: InputStream = getClass.getResourceAsStream(filePath)
    val xml = XML.load(stream)

    // Extract tile ids and their types
    val tiles = (xml \\ "tile").map { tileNode =>
      val id = (tileNode \ "@id").text.toInt
      val tileType = (tileNode \ "@type").text
      (id, tileType)
    }.toMap

    tiles
  }

  def reset(): Unit = {
    cells = Array.tabulate(width, height) { (x, y) =>
      new Cell(x, y, isWall = true, this)
    }
    goal = cells(width - 1)(height - 1)
    generate()
  }


  def cellAt(x: Int, y: Int): Option[Cell] = {
    if (x >= 0 && x < width && y >= 0 && y < height) Some(cells(x)(y))
    else None
  }

  def addEnemy(cell: Cell, enemy: Enemy): Unit = {
    enemies += (cell -> enemy)
  }



  private def createRandomEnemy(cell: Cell, enemyPool: List[(EnemySpecies, Range)]): Enemy = {
    val random = new Random()
    val (species, levelRange) = enemyPool(random.nextInt(enemyPool.size))
    val level = levelRange(random.nextInt(levelRange.size))
    new Enemy(species = species, level = level, currentCell = cell)
  }

  def generateEnemies(numEnemies: Int, enemyPool: List[(EnemySpecies, Range)]): Unit = {
    val random = new Random()
    var enemiesCount = 0

    val viableCells = for {
      x <- 0 until width
      y <- 0 until height
      cell = cells(x)(y)
      tileType1 = tileTypes.getOrElse(layer1(y)(x), "")
      tileID2 = layer2(y)(x)
      if !cell.isWall && !enemies.contains(cell) && tileType1 != "blank" && tileID2 != 0
    } yield cell

    val shuffledCells = random.shuffle(viableCells.toList)

    for (cell <- shuffledCells.take(numEnemies)) {
      val enemy = createRandomEnemy(cell, enemyPool)
      addEnemy(cell, enemy)
      enemiesCount += 1
    }
  }

}

