package ch.makery.address.controller

import ch.makery.address.GameApp
import ch.makery.address.model._
import javafx.fxml.FXML
import javafx.scene.control.{Alert, ButtonType, TextField}
import scalafx.scene.input.{KeyCode, KeyEvent}
import scalafx.Includes._
import javafx.scene.layout.GridPane
import scalafx.scene.Node
import scalafx.scene.image.{Image, ImageView}
import scalafx.scene.paint.Color
import scalafx.scene.shape.Rectangle
import scalafx.scene.layout.GridPane.sfxGridPane2jfx
import scalafx.scene.web.WebEvent.Alert

import scala.collection.mutable




class MazeController() {
  @FXML
  private var mazeView: GridPane = _
  private var gameController: GameController = _
  private var prevPlayerCell: Option[Cell] = None
  private var currentPlayerStackPane: Option[scalafx.scene.layout.StackPane] = None
  private lazy val stackPaneArray: Array[Array[scalafx.scene.layout.StackPane]] = Array.fill(gameController.maze.width, gameController.maze.height)(null)
  private var enemy: Enemy = _


  def setGameController(gameController: GameController): Unit = {
    this.gameController = gameController
  }


  def setup(): Unit = {
    drawMaze()
    mazeView.onKeyPressed = handleKeyPress _
    mazeView.requestFocus()
  }


  @FXML
  def handleKeyPress(ke: KeyEvent): Unit = {
    ke.code match {
      case KeyCode.Up =>
        gameController.player.move(0, -1)
        gameController.player.setSprite("up")
      case KeyCode.Down =>
        gameController.player.move(0, 1)
        gameController.player.setSprite("down")
      case KeyCode.Left =>
        gameController.player.move(-1, 0)
        gameController.player.setSprite("left")
      case KeyCode.Right =>
        gameController.player.move(1, 0)
        gameController.player.setSprite("right")
      case KeyCode.E => gameController.enterInventoryView()
      case _ =>
    }

    if (ke.code == KeyCode.Space) {

      doorPlayerIsInFrontOf().foreach { doorType =>
        if (doorType == "door4") {
          val boss = new Enemy(EnemySpeciesList.Blood_Lich, 10, gameController.player.currentCell)
          gameController.enterBattleView(boss)
          gameController.startBattle(boss)

        } else {
          enterNewMaze(doorType)
        }
      }
      println("End of space key logic")
    }
    updatePlayerPosition()
    checkWin()
    checkEncounter().foreach { enemy =>
      gameController.enterBattleView(enemy)
      gameController.startBattle(enemy)
    }
  }

  val cellSize = 40

  val tileImagesCache: mutable.Map[String, Image] = mutable.Map()

  val doorToMazeMap: Map[String, String] = Map(
    "door0" -> "/MazeView.tmx",
    "door1" -> "/MazeView1.tmx",
    "door2" -> "/MazeView2.tmx",
    "door3" -> "/MazeView1.tmx",
    "door4" -> "/MazeView2.tmx"
  )

  val doorSpawnPositions: Map[String, (Int, Int)] = Map(
    "door0" -> (25, 2),
    "door1" -> (3, 2),
    "door2" -> (9,2),
    "door3" -> (27,2),
    "door4" -> (25,2)

  )


  def drawMaze(): Unit = {
    val scalaFXGridPane = new scalafx.scene.layout.GridPane(mazeView)
    scalaFXGridPane.children.clear()

    for (x <- 0 until gameController.maze.width; y <- 0 until gameController.maze.height) {
      val cell = gameController.maze.cells(x)(y)

      // Draw the maze tile from layer 1
      val imagePathLayer1 = gameController.maze.tileMap(gameController.maze.layer1(y)(x))
      val resourceLayer1 = getClass.getResource(imagePathLayer1)
      val tileImageLayer1 = tileImagesCache.getOrElseUpdate(resourceLayer1.toExternalForm(), new Image(resourceLayer1.toExternalForm()))
      val tileImageViewLayer1 = new ImageView() {
        image = tileImageLayer1
        fitWidth = cellSize
        fitHeight = cellSize
      }

      // Draw the maze tile from layer 2
      val imagePathLayer2 = gameController.maze.tileMap(gameController.maze.layer2(y)(x))
      val resourceLayer2 = getClass.getResource(imagePathLayer2)
      val tileImageLayer2 = tileImagesCache.getOrElseUpdate(resourceLayer2.toExternalForm(), new Image(resourceLayer2.toExternalForm()))
      val tileImageViewLayer2 = new ImageView() {
        image = tileImageLayer2
        fitWidth = cellSize
        fitHeight = cellSize
      }

      val stackPane = new scalafx.scene.layout.StackPane
      stackPane.children.addAll(tileImageViewLayer1, tileImageViewLayer2)

      stackPaneArray(x)(y) = stackPane

      GridPane.setConstraints(stackPane, x, y)

      if (gameController.player.currentCell == cell) {
        stackPane.children.add(gameController.player.playerImageView)
        currentPlayerStackPane = Some(stackPane)
      }
      scalaFXGridPane.add(stackPane, x, y)
    }
  }


  def enterNewMaze(doorType: String): Unit = {
    val tmxFilePath = doorToMazeMap(doorType)
    val newMaze = new Maze(32, 20, tmxFilePath)

    gameController.maze = newMaze
    val (spawnX, spawnY) = doorSpawnPositions(doorType)
    gameController.player.currentCell = newMaze.cells(spawnX)(spawnY)

    newMaze.generate()
    doorType match {
      case "door0" => newMaze.generateEnemies(50, MazeEnemyPools.maze1Pool)
      case "door1" => newMaze.generateEnemies(50, MazeEnemyPools.maze2Pool)
      case "door2" => newMaze.generateEnemies(50, MazeEnemyPools.maze3Pool)
      case "door3" => newMaze.generateEnemies(50, MazeEnemyPools.maze2Pool)
      case "door4" => newMaze.generateEnemies(50, MazeEnemyPools.maze3Pool)
    }
    drawMaze()
  }


  def updatePlayerPosition(): Unit = {
    val scalaFXGridPane = new scalafx.scene.layout.GridPane(mazeView)

    currentPlayerStackPane.foreach { sp =>
      sp.children.remove(gameController.player.playerImageView)
    }

    val currentCell = gameController.player.currentCell
    val currentStackPane = Some(stackPaneArray(currentCell.x)(currentCell.y))

    currentStackPane.foreach { sp =>
      sp.children.add(gameController.player.playerImageView) // Add to the end of the list
      currentPlayerStackPane = Some(sp)
    }
  }

  def doorPlayerIsInFrontOf(): Option[String] = {
    val adjacentOffsets = List((-1, 0), (1, 0), (0, -1), (0, 1))

    for ((dx, dy) <- adjacentOffsets) {
      val adjacentCell = gameController.player.currentCell.neighbor(dx, dy)

      if (adjacentCell.isDefined) {
        val tileID = gameController.maze.layer2(adjacentCell.get.y)(adjacentCell.get.x)
        val tileType = gameController.maze.tileTypes.getOrElse(tileID, "")

        if (doorToMazeMap.contains(tileType)) {
          return Some(tileType)
        }
      }
    }
    None
  }


  def checkWin(): Unit = {
    if (gameController.player.currentCell == gameController.maze.goal) {
      println("You win!")
      gameController.player.reset(gameController.maze.start)
      drawMaze()
    }
  }

  def checkEncounter(): Option[Enemy] = {
    val currentCell = gameController.player.currentCell
    gameController.maze.enemies.get(currentCell).map { enemy =>
      gameController.enterBattleView(enemy)
      gameController.startBattle(enemy)
      enemy
    }
  }


}
