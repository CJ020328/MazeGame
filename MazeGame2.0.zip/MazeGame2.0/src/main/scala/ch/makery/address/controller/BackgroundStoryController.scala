package ch.makery.address.controller

import ch.makery.address.GameApp
import javafx.fxml.FXMLLoader
import scalafx.scene.{Parent, Scene}
import scalafx.scene.layout.AnchorPane

class BackgroundStoryController {

  def handleStartGame(): Unit = {
    GameApp.startMazeGame()
  }


  def handleBack(): Unit = {
    val resource = getClass.getResource("/ch/makery/address/view/MenuView.fxml")
    val loader = new FXMLLoader(resource)
    loader.load()
    val roots: Parent = new AnchorPane(loader.getRoot[javafx.scene.layout.AnchorPane])
    GameApp.stage.scene = new Scene(roots)
  }
}