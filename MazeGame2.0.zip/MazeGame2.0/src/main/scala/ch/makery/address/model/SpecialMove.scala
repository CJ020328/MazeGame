package ch.makery.address.model

sealed trait MoveType
case object DamageMove extends MoveType
case object DefenseMove extends MoveType
case object PoisonMove extends MoveType
case object ImmobilizeMove extends MoveType
case object FocusBuffMove extends MoveType
case object VeryFocusBuffMove extends MoveType
case object DelayedMove extends MoveType
case object DefenseBuffMove extends MoveType
case object BuffMove extends MoveType
case object LeechMove extends MoveType
case object DebuffMove extends MoveType


case class SpecialMove(name: String, damageMultiplier: Double, mpCost: Int, description: String, moveType: MoveType, level: Int)
