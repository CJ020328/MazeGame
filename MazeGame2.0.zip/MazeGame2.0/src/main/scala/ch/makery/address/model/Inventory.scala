package ch.makery.address.model

import scala.collection.mutable.ListBuffer

class Inventory {
  var items: ListBuffer[Item] = ListBuffer()

  def addItem(item: Item): Unit = {
    val existingItemOption = items.find(_.name == item.name)
    existingItemOption match {
      case Some(existingItem) =>
        if (existingItem.quantity == 0) {
          items += item
        } else {
          existingItem.quantity += 1
        }
      case None => items += item
    }
  }

  def removeItem(item: Item): Unit = {
    val existingItemOption = items.find(_.name == item.name)
    existingItemOption match {
      case Some(existingItem) =>
        existingItem.quantity -= 1
        if (existingItem.quantity <= 0) {
          items -= existingItem
        }
      case None => // do nothinginve
    }
  }
}


