package ch.makery.address.model

object EnemySpeciesList {
  val pharaohsBlessing = SpecialMove(
    "Pharaoh's Blessing",
    1.0, 5,
    "Harnesses the ancient powers to increase defense and heal.",
    BuffMove, 1
  )

  val scarabSwarm = SpecialMove(
    "Scarab Swarm",
    1.5, 4,
    "Summons a swarm of scarabs to attack the player over time.",
    PoisonMove, 2
  )

  val sandstorm = SpecialMove(
    "Sandstorm",
    1.2, 5,
    "Summons a fierce sandstorm, causing damage over time",
    PoisonMove, 3
  )

  val quicksandGrasp = SpecialMove(
    "Quicksand Grasp",
    1.0, 4,
    "Traps the player in quicksand, immobilizing them for a turn.",
    ImmobilizeMove, 4
  )

  val arrowStorm = SpecialMove(
    "Arrow Storm",
    1.4, 4,
    "Releases a flurry of arrows, dealing significant damage.",
    DamageMove, 5
  )

  val snaringShot = SpecialMove(
    "Snaring Shot",
    1.0, 4,
    "Fires a snaring arrow, immobilizing the player for a turn.",
    ImmobilizeMove, 6
  )

  val curseOfImmobility = SpecialMove(
    "Curse of Immobility",
    1.0, 5,
    "Curses the player, preventing movement for two rounds.",
    ImmobilizeMove, 7
  )

  val revenantsWrath = SpecialMove(
    "Revenant's Wrath",
    1.5, 3,
    "Delivers a powerful attack, dealing high damage.",
    DamageMove, 8
  )

  val shieldingStance = SpecialMove(
    "Shielding Stance",
    1.0, 4,
    "Assumes a defensive stance, increasing defense by 30% for 3 turns.",
    BuffMove,
    9
  )

  val sandArmor = SpecialMove(
    "Sand Armor",
    1.0, 4,
    "Forms a protective layer of sand, reducing damage taken by 50% for 2 turns.",
    DefenseBuffMove,
    10
  )

  val lifeLeech = SpecialMove(
    "Life Leech",
    0.8, 5,
    "Drains health from the player, healing itself by the same amount.",
    LeechMove,
    11
  )

  val graspingShadows = SpecialMove(
    "Grasping Shadows",
    0.7, 4,
    "Shadows grasp the player, immobilizing them for a turn.",
    ImmobilizeMove,
    12
  )

  val soulDrain = SpecialMove(
    "Soul Drain",
    1.2, 5,
    "Drains the life force of the player, healing the Blood Lich for half the damage dealt.",
    LeechMove,
    13
  )

  val lichsCurse = SpecialMove(
    "Lich's Curse",
    1.0, 6,
    "Curses the player, reducing their attack and defense by 25% for 3 turns.",
    DebuffMove,
    14
  )

  val necromanticSurge = SpecialMove(
    "Necromantic Surge",
    1.3, 6,
    "Dark energy engulfs the player, dealing massive damage over 3 turns.",
    PoisonMove,
    15
  )

  val wraithsEmbrace = SpecialMove(
    "Wraith's Embrace",
    1.0, 7,
    "Channels the spirit of a wraith, increasing Blood Lich's attack and defense by 20% for 3 turns.",
    BuffMove,
    16
  )



  val Royal_Scarad = EnemySpecies("Royal Scarad", 25, 10, 2, 25, "/image/enemy/tile000.png", List(pharaohsBlessing, scarabSwarm))
  val Sand_Ghoul = EnemySpecies("Sand Ghoul", 40, 15, 5, 35, "/image/enemy/tile001.png", List(sandstorm, quicksandGrasp))
  val Rotting_Archer = EnemySpecies("Rotting Archer", 30, 20, 2, 35, "/image/enemy/tile005.png", List(arrowStorm, snaringShot))
  val Grave_Revenant = EnemySpecies("Grave Revenant", 30, 25 , 5, 50, "/image/enemy/tile009.png", List(curseOfImmobility, revenantsWrath))
  val Ancient_Fighter = EnemySpecies("Ancient Fighter", 35, 15, 10, 50, "/image/enemy/tile012.png", List(shieldingStance, sandArmor))
  val Skittering_Hand = EnemySpecies("Skittering Hand", 60, 15, 5, 50, "/image/enemy/tile017.png", List(lifeLeech, graspingShadows))
  val Blood_Lich = EnemySpecies("Blood Lich", 200, 30, 10, 200, "/image/enemy/tile028.png", List(soulDrain, wraithsEmbrace, lichsCurse, necromanticSurge))

}

class Enemy(val species: EnemySpecies, val level: Int, var currentCell: Cell) {
  private def calculateIncrement(base: Int, multiplier: Double, times: Int): Int = {
    var result = base.toDouble
    for (_ <- 1 until times) {
      result *= multiplier
    }
    result.toInt
  }

  var health: Int = calculateIncrement(species.baseHealth, 1.15, level)
  var attackPower: Int = calculateIncrement(species.baseAttackPower, 1.15, level)
  var defense: Int = calculateIncrement(species.baseDefense, 1.15, level)
  val experiencePoints: Int = calculateIncrement(species.baseExperiencePoints, 1.15, level)

  val imagePath: String = species.imagePath
  val maxHealth: Int = health
  var poisonTurnsLeft: Int = 0
  var isParalyzed: Boolean = false
  var pharaohsBlessingTurnsLeft: Int = 0
  var curseOfImmobilityTurnsLeft: Int = 0
  var shieldingStanceTurnsLeft: Int = 0
  var damageReductionTurnsLeft: Int = 0
  var damageReductionMultiplier: Double = 1.0
  var wraitEmbraceTurnLeft: Int = 0

  def specialMoves: List[SpecialMove] = species.specialMoves

  def isPoisoned: Boolean = poisonTurnsLeft > 0

  def useSpecialMove(player: Player): String = {
    val selectedMove = specialMoves(scala.util.Random.nextInt(specialMoves.size))

    selectedMove.moveType match {

      case DamageMove =>
        if (selectedMove.name == "Arrow Storm") {
          val damage = Math.max(0, (attackPower * selectedMove.damageMultiplier).toInt - player.defense)
          player.health -= damage
          if (player.health <= 0) {
            player.health = 0
          }
          s"${species.name} used ${selectedMove.name}! ${player.name} takes $damage damage from the flurry of arrows."
        } else if (selectedMove.name == "Revenant's Wrath") {
          val damage = Math.max(0, (attackPower * selectedMove.damageMultiplier).toInt - player.defense)
          player.health -= damage
          if (player.health <= 0) {
            player.health = 0
          }
          s"${species.name} used ${selectedMove.name}! ${player.name} takes $damage damage from the Revenant's wrath."
        } else {
          ""
        }

      case BuffMove =>
        if (selectedMove.name == "Pharaoh's Blessing") {
          pharaohsBlessingTurnsLeft = 3
          defense += (defense * 0.2).toInt
          health += (maxHealth * 0.1).toInt
          if (health > maxHealth) health = maxHealth
          s"${species.name} used ${selectedMove.name}! Defense increased and health restored for 3 turns!"
        } else if (selectedMove.name == "Shielding Stance") {
          shieldingStanceTurnsLeft = 3
          defense += (defense * 0.3).toInt
          s"${species.name} used ${selectedMove.name}! Defense increased for 3 turns!"
        } else if (selectedMove.name == "Wraith's Embrace") {
          wraitEmbraceTurnLeft = 3
          attackPower += (attackPower * 0.2).toInt
          defense += (defense * 0.2).toInt
          s"${species.name} used ${selectedMove.name}! Attack and defense increased for 3 turns!"
        } else {
          ""
        }

      case PoisonMove =>
        if (selectedMove.name == "Scarab Swarm") {
          player.poisonTurnsLeft += 3
          s"${species.name} used ${selectedMove.name}! ${player.name} will take damage over time from the scarabs!"
        } else if (selectedMove.name == "Sandstorm") {
          player.poisonTurnsLeft += 2
          s"${species.name} used ${selectedMove.name}! ${player.name} is blinded and will take damage over time!"
        } else if (selectedMove.name == "Necromantic Surge") {
          player.poisonTurnsLeft += 3
          s"${species.name} used ${selectedMove.name}! ${player.name} is engulfed in dark energy and will take damage over 3 turns!"
        } else {
         ""
        }
      case ImmobilizeMove =>
        if (selectedMove.name == "Snaring Shot") {
          player.cannotMove = true
          s"${species.name} used ${selectedMove.name}! ${player.name} is snared and cannot move next turn!"
        } else if (selectedMove.name == "Quicksand Grasp") {
          player.cannotMove = true
          s"${species.name} used ${selectedMove.name}! ${player.name} is trapped in quicksand and cannot move next turn!"
        } else if (selectedMove.name == "Curse of Immobility") {
          player.cannotMove = true
          curseOfImmobilityTurnsLeft = 2
          s"${species.name} used ${selectedMove.name}! ${player.name} is cursed and cannot move for the next two turns!"
        } else if (selectedMove.name == "Grasping Shadows") {
          val damage = Math.max(0, (attackPower * selectedMove.damageMultiplier).toInt - player.defense)
          player.health -= damage
          player.cannotMove = true
          s"${species.name} used ${selectedMove.name}! ${player.name} takes $damage damage and is immobilized for the next turn!"
        } else {
          ""
        }
      case DefenseBuffMove =>
        if (selectedMove.name == "Sand Armor") {
          damageReductionTurnsLeft = 2
          damageReductionMultiplier = 0.5
          s"${species.name} used ${selectedMove.name}! Damage taken is reduced by 50% for 2 turns!"
        } else {
          ""
        }

      case LeechMove =>
        if (selectedMove.name == "Life Leech") {
          val damage = Math.max(0, (attackPower * selectedMove.damageMultiplier).toInt - player.defense)
          player.health -= damage
          if (player.health <= 0) {
            player.health = 0
          }
          health += damage
          if (health > maxHealth) health = maxHealth
          s"${species.name} used ${selectedMove.name}! ${player.name} loses $damage health and ${species.name} restores the same amount!"
        } else if (selectedMove.name == "Soul Drain") {
          val damage = Math.max(0, (attackPower * selectedMove.damageMultiplier).toInt - player.defense)
          player.health -= damage
          if (player.health <= 0) {
            player.health = 0
          }
          health += (damage * 0.4).toInt
          if (health > maxHealth) health = maxHealth
          s"${species.name} used ${selectedMove.name}! ${player.name} loses $damage health and ${species.name} restores ${(damage * 0.5).toInt} health!"
        } else {
          ""
        }

      case DebuffMove =>
        if (selectedMove.name == "Lich's Curse") {
          player.attackPower -= (player.attackPower * 0.25).toInt
          player.defense -= (player.defense * 0.25).toInt
          player.lichsCurseTurnsLeft = 3
          s"${species.name} used ${selectedMove.name}! ${player.name}'s attack and defense are reduced for 3 turns!"
        } else {
          ""
        }


      case _ =>
        // Existing logic for other moves
        val damage = Math.max(0, (attackPower * selectedMove.damageMultiplier).toInt - player.defense)
        player.health -= damage
        if (player.health <= 0) {
          player.health = 0
        }
        s"${species.name} used ${selectedMove.name}! ${player.name} takes $damage damage."
    }
  }

  def applyPharaohsBlessingEffect(): Unit = {
    if (pharaohsBlessingTurnsLeft > 0) {
      pharaohsBlessingTurnsLeft -= 1

      // If the Pharaoh's Blessing effect has ended, revert the defense buff
      if (pharaohsBlessingTurnsLeft == 0) {
        defense -= (defense * 0.2).toInt // Decrease defense by 20%
      }
    }
  }

  def applyCurseOfImmobilityEffect(player: Player): Unit = {
    if (curseOfImmobilityTurnsLeft > 0) {
      curseOfImmobilityTurnsLeft -= 1

      // If the Curse of Immobility effect has ended, allow the player to move
      if (curseOfImmobilityTurnsLeft == 0) {
        player.cannotMove = false
      }
    }
  }

  def applyPoisonEffect(): Unit = {
    if (isPoisoned) {
      val poisonDamage = (maxHealth * 0.15).toInt
      health -= poisonDamage
      if (health < 0) health = 0
      poisonTurnsLeft -= 1
    }
  }

  def applyShieldingStanceEffect(): Unit = {
    if (shieldingStanceTurnsLeft > 0) {
      shieldingStanceTurnsLeft -= 1

      if (shieldingStanceTurnsLeft == 0) {
        defense -= (defense * 0.3).toInt
      }
    }
  }

  def applySandArmorEffect(): Unit = {
    if (damageReductionTurnsLeft > 0) {
      damageReductionTurnsLeft -= 1

      if (damageReductionTurnsLeft == 0) {
        damageReductionMultiplier = 1.0
      }
    }
  }

  def applyWraithsEmbraceEffect(): Unit = {
    if (wraitEmbraceTurnLeft > 0) {
      wraitEmbraceTurnLeft -= 1

      if (wraitEmbraceTurnLeft == 0) {
        attackPower -= (attackPower * 0.2).toInt
        defense -= (defense * 0.2).toInt
      }
    }
  }

  def applyAllEffects(): Unit = {
    applyPharaohsBlessingEffect()
    applyPoisonEffect()
    applyShieldingStanceEffect()
    applySandArmorEffect()
    applyWraithsEmbraceEffect()
  }

  def resetDebuffs(): Unit = {
    poisonTurnsLeft = 0
    isParalyzed = false
    pharaohsBlessingTurnsLeft = 0
    curseOfImmobilityTurnsLeft = 0
    shieldingStanceTurnsLeft = 0
    damageReductionTurnsLeft = 0
    damageReductionMultiplier = 1.0
    wraitEmbraceTurnLeft = 0
  }

  def attack(player: Player): Option[String] = {
    if (isParalyzed) {
      isParalyzed = false
      return Some(s"${species.name} is paralyzed and cannot attack!")
    }
    val damage = if (player.shieldTurnsLeft > 0) {
      Math.max(0, (attackPower * 0.5).toInt - player.defense)
    } else {
      Math.max(0, attackPower - player.defense)
    }
    if (player.specialDefenseActive) {
      if (player.health - damage > 1) {
        player.health -= damage
      } else {
        player.health = 1
      }
      player.specialDefenseActive = false // Reset the special defense after using it
    } else {
      player.health -= damage
    }
    if (player.health <= 0) {
      player.health = 0
    }
    None
  }

}
