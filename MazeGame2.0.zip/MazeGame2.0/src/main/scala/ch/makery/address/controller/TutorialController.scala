package ch.makery.address.controller

import ch.makery.address.GameApp
import scalafx.scene.{Parent, Scene}
import scalafx.scene.layout.AnchorPane
import scalafxml.core.{NoDependencyResolver, ControllerDependencyResolver}


import javafx.fxml.FXMLLoader

class TutorialController(resolver: ControllerDependencyResolver) {

  def this() = this(NoDependencyResolver)

  def handleNext(): Unit = {
    val resource = getClass.getResource("/ch/makery/address/view/BackgroundStoryView.fxml")
    val loader = new FXMLLoader(resource)
    loader.load()
    val roots: Parent = new AnchorPane(loader.getRoot[javafx.scene.layout.AnchorPane])
    GameApp.stage.scene = new Scene(roots)
  }

  def handleBackToMenu(): Unit = {
    val resource = getClass.getResource("/ch/makery/address/view/MenuView.fxml")
    val loader = new FXMLLoader(resource)
    loader.load()
    val roots: Parent = new AnchorPane(loader.getRoot[javafx.scene.layout.AnchorPane])
    GameApp.stage.scene = new Scene(roots)
  }
}
