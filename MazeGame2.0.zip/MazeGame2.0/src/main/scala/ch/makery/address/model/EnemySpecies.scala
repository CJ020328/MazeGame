package ch.makery.address.model

case class
EnemySpecies(name: String, baseHealth: Int, baseAttackPower: Int, baseDefense: Int, baseExperiencePoints: Int, imagePath: String, specialMoves: List[SpecialMove] )
