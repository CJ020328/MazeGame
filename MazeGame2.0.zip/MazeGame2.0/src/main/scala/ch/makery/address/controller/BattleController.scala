package ch.makery.address.controller

import ch.makery.address.model._
import javafx.fxml.FXML
import javafx.scene.layout.HBox
import javafx.scene.layout.VBox
import scalafx.scene.control.{Button, ProgressBar}
import javafx.scene.text.Text
import scalafx.animation.PauseTransition
import scalafx.util.Duration
import javafx.scene.control.{ButtonType, ChoiceDialog, SplitPane}
import javafx.scene.image.{Image, ImageView}
import scalafx.application.Platform

import scala.collection.JavaConverters._

import javax.swing.JOptionPane

import scala.concurrent.duration.DurationInt

class BattleController {
  var gameController: GameController = _
  var playerTurn: Boolean = true
  var battleActive: Boolean = false

  @FXML
  private var BattleViewPane: SplitPane = _
  @FXML
  private var topSectionPane: HBox = _
  @FXML
  private var currentPlayerLabel: Text = _
  @FXML
  private var middleSectionPane: VBox = _
  @FXML
  private var enemyInfoText: Text = _
  @FXML
  private var playerInfoLabel: javafx.scene.control.Label = _
  @FXML
  private var bottomSectionPane: HBox = _
  @FXML
  private var attackButton: javafx.scene.control.Button = _
  @FXML
  private var specialMoveButton: javafx.scene.control.Button = _
  @FXML
  private var itemButton:javafx.scene.control.Button = _
  @FXML
  private var waitButton: javafx.scene.control.Button = _
  @FXML
  private var runButton: javafx.scene.control.Button = _
  @FXML
  private var messageLabel: javafx.scene.control.Label = _
  @FXML
  private var playerHpBar: javafx.scene.control.ProgressBar = _
  @FXML
  private var enemyHpBar: javafx.scene.control.ProgressBar = _
  @FXML
  private var playerImageView: ImageView = _
  @FXML
  private var enemyImageView: ImageView = _
  @FXML
  private var playerMpBar: javafx.scene.control.ProgressBar = _

  def setGameController(gameController: GameController): Unit = {
    this.gameController = gameController
    playerImageView.setImage(gameController.player.playerStaticImage)
  }

  def startBattle(): Unit = {
    setupBattleView()
    disableButtons()
    messageLabel.setText("")
    val pause = new PauseTransition(Duration(2000))
    pause.setOnFinished(_ => {
      messageLabel.setText(s"A ${gameController.currentEnemy.getOrElse(return).species.name} has appeared! Get ready for battle!")
      enableButtons()
    })
    pause.play()
  }

  def setupBattleView(): Unit = {
    playerImageView.setFitWidth(100)
    playerImageView.setFitHeight(100)

    val currentEnemy = gameController.currentEnemy.getOrElse(return)
    enemyImageView.setImage(new Image(currentEnemy.imagePath))

    if (currentEnemy.species.name == "Blood Lich") {
      enemyImageView.setFitWidth(300)
      enemyImageView.setFitHeight(200)
    } else {
      enemyImageView.setFitWidth(100)
      enemyImageView.setFitHeight(100)
    }

    enemyInfoText.setText(s"Level: ${currentEnemy.level} ${currentEnemy.species.name} - HP: ${currentEnemy.health}")
    playerInfoLabel.textProperty().set(s"Level: ${gameController.player.level} Player 1 - HP: ${gameController.player.health}")

    updateBars()
  }

  def attack(): Unit = {
    playerAttack(gameController.currentEnemy.getOrElse(return))
  }

  def show(): Unit ={
    showItems()
  }

  def stay(): Unit = {
    playerWait()
  }

  def run(): Unit = {
    playerRun()
  }

  def enemyTurn(): Unit = {
    val currentEnemy = gameController.currentEnemy.getOrElse(return)
    applyCurseOfImmobilityEffect()
    currentEnemy.applyAllEffects()

    if (currentEnemy.health <= 0) {
      handleEnemyDefeat(currentEnemy)
      return
    }
    val useSpecialMoveChance = 0.5
    if (scala.util.Random.nextDouble() < useSpecialMoveChance) {
      val specialMoveResult = currentEnemy.useSpecialMove(gameController.player)
      updateBattleView(specialMoveResult, 0)
    } else {
      val initialPlayerHealth = gameController.player.health
      val attackResult = currentEnemy.attack(gameController.player)
      val damageDealt = initialPlayerHealth - gameController.player.health
      attackResult match {
        case Some(message) =>
          updateBattleView(message, 0)
        case None =>
          updateBattleView(s"${currentEnemy.species.name} attacks! ${gameController.player.name} takes $damageDealt damage.", 0)
      }
    }

    updateBars()

    if (gameController.player.cannotMove) {
      val aftermathPause = new PauseTransition(Duration(2000))
      aftermathPause.setOnFinished(_ => {
        messageLabel.setText("You are immobilized and cannot move!")
        val secondEnemyTurnPause = new PauseTransition(Duration(2000))
        secondEnemyTurnPause.setOnFinished(_ => {
          gameController.player.cannotMove = false
          enemyTurn()
        })
        secondEnemyTurnPause.play()
      })
      aftermathPause.play()
    } else {
      val pause = new PauseTransition(Duration(2000))
      pause.setOnFinished(_ => {
        if (gameController.player.health <= 0) {
          handlePlayerDefeat()
        } else {
          enableButtons()
          messageLabel.setText("Now it's your turn!")
          playerTurn = true
          battleActive = false
        }
      })
      pause.play()
    }
  }

  def handlePostPlayerMove(enemy: Enemy): Unit = {
    disableButtons()
    val pause = new PauseTransition(Duration(2000))
    pause.setOnFinished(_ => {
      if (enemy.health <= 0) {
        handleEnemyDefeat(enemy)
      } else if (gameController.player.cannotMove) {
        messageLabel.setText("You are still reeling from the aftermath of the powerful strike and can't move!")
        val aftermathPause = new PauseTransition(Duration(2000))
        aftermathPause.setOnFinished(_ => enemyTurn())
        aftermathPause.play()
      } else {
        messageLabel.setText("Now it's the enemy's turn!")
        enemyTurn()
      }
    })
    pause.play()
  }

  def showLearnedAbilities(): Unit = {
    val learnedMoves = gameController.player.specialMoves.filter(move =>
      move.level > gameController.player.lastLevel && move.level <= gameController.player.level
    )

    if (learnedMoves.nonEmpty) {
      val movesDescriptions = learnedMoves.map(move => s"${move.name} (Level ${move.level}): ${move.description}").mkString("\n\n")
      javafx.application.Platform.runLater(() => {
        val dialog = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION)
        dialog.setTitle("New Abilities Learned!")
        dialog.setHeaderText("Congratulations! You've learned the following abilities:")
        dialog.setContentText(movesDescriptions)
        dialog.showAndWait()
      })
    }
  }

  def handleEnemyDefeat(enemy: Enemy): Unit = {
    gameController.maze.enemies -= enemy.currentCell
    gameController.player.gainExperience(enemy.experiencePoints)
    gameController.player.resetFocusAfterBattle()
    enemy.resetDebuffs()
    battleActive = false
    var victoryMessage = s"You defeated ${enemy.species.name} and gained ${enemy.experiencePoints} experience points!"
    if (gameController.player.didLevelUp) {
      victoryMessage += s" You have leveled up to Level ${gameController.player.level}!"
      showLearnedAbilities()
      gameController.player.didLevelUp = false
    }

    if (enemy.species.name == "Blood Lich") {
      Platform.runLater(() => {
        val alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.CONFIRMATION, "Congratulations! You have finished the game. Do you want to play New Game Plus?", ButtonType.YES, ButtonType.NO)
        val result = alert.showAndWait()

        if (result.isPresent && result.get() == ButtonType.YES) {
          val mainMaze = new Maze(32, 20, "/MazeView.tmx")
          gameController.maze = mainMaze
          gameController.maze.generateEnemies(50, MazeEnemyPools.maze1Pool)
          gameController.maze.generate()

          gameController.player.currentCell = gameController.maze.start
          gameController.player.health = gameController.player.maxHealth
          gameController.player.mp = gameController.player.maxMp
        }
      })
    }
    updateBattleView(victoryMessage, 0)
    val pauseEndBattle = new PauseTransition(Duration(3000))
    pauseEndBattle.setOnFinished(_ => gameController.exitBattleView())
    pauseEndBattle.play()
  }

  def handlePlayerDefeat(): Unit = {
    updateBattleView("You have been defeated. You wake up at the start of the maze...", 0)

    val mainMaze = new Maze(32, 20, "/MazeView.tmx")
    gameController.maze = mainMaze
    gameController.maze.generateEnemies(50, MazeEnemyPools.maze1Pool)
    gameController.maze.generate()

    gameController.player.currentCell = gameController.maze.start
    gameController.player.health = gameController.player.maxHealth
    gameController.player.mp = gameController.player.maxMp

    val pauseEndBattle = new PauseTransition(Duration(3000))
    pauseEndBattle.setOnFinished(_ => gameController.exitBattleView())
    pauseEndBattle.play()
  }

  def playerAttack(enemy: Enemy): Unit = {
    if (!playerTurn || battleActive || gameController.player.cannotMove) {
      return
    }
    applyCurseOfImmobilityEffect()
    gameController.player.endOfTurnEffects()
    battleActive = true
    playerTurn = false
    val damageDealt = gameController.player.attack(enemy)
    updateBars()
    updateBattleView(s"You attacked ${enemy.species.name} for $damageDealt damage!", 0)
    handlePostPlayerMove(enemy)
  }

  import javafx.application.Platform

  def useSpecialMove(): Unit = {
    if (!playerTurn || battleActive || gameController.player.cannotMove) {
      return
    }
    gameController.player.endOfTurnEffects()
    applyCurseOfImmobilityEffect()
    val availableMoves = gameController.player.specialMoves.filter(_.level <= gameController.player.level)

    val choices = availableMoves.map(_.name).toList
    val dialog = new ChoiceDialog[String](choices.head, choices.asJava)
    dialog.setTitle("Special Move")
    dialog.setHeaderText("Choose a special move:")
    dialog.setContentText("Move:")

    Platform.runLater(() => {
      val listViewOpt = Option(dialog.getDialogPane().lookup(".list-view")).map(_.asInstanceOf[javafx.scene.control.ListView[String]])

      listViewOpt.foreach(listView => {
        listView.setCellFactory(_ => new javafx.scene.control.ListCell[String] {
          override def updateItem(item: String, empty: Boolean): Unit = {
            super.updateItem(item, empty)
            if (item != null) {
              setText(item)
              gameController.player.specialMoves.find(_.name == item).foreach { move =>
                setTooltip(new javafx.scene.control.Tooltip(move.description))
              }
            } else {
              setText(null)
              setTooltip(null)
            }
          }
        })
      })

      if (listViewOpt.isEmpty) {
        dialog.getDialogPane().getChildrenUnmodifiable().forEach(child => println(child.getClass))
      }
    })

    val result = dialog.showAndWait()
    result.ifPresent(moveName => {
      val specialMove = gameController.player.specialMoves.find(_.name == moveName).getOrElse(return)
      val enemy = gameController.currentEnemy.getOrElse(return)
      val actionResult = gameController.player.useSpecialMove(specialMove, enemy)
      updateBars()
      updateBattleView(actionResult, 0)
      handlePostPlayerMove(enemy)
    })
  }

  def playerWait(): Unit = {
    if (!playerTurn || battleActive || gameController.player.cannotMove) {
      return
    }
    gameController.player.endOfTurnEffects()
    applyCurseOfImmobilityEffect()
    battleActive = true
    playerTurn = false
    disableButtons()
    messageLabel.setText("You decided to wait. Now it's the enemy's turn!")
    val pause = new PauseTransition(Duration(2000))
    pause.setOnFinished(_ => enemyTurn())
    pause.play()
  }

  def playerRun(): Unit = {
    if (!playerTurn || battleActive || gameController.player.cannotMove) {
      return
    }
    gameController.player.endOfTurnEffects()
    applyCurseOfImmobilityEffect()
    battleActive = true
    playerTurn = false
    disableButtons()
    if (gameController.player.tryToEscape()) {
      messageLabel.setText("You successfully escaped from the battle.")
      gameController.player.resetFocusAfterBattle()
      val pauseEndBattle = new PauseTransition(Duration(2000))
      pauseEndBattle.setOnFinished(_ => gameController.exitBattleView())
      pauseEndBattle.play()
    } else {
      messageLabel.setText("You failed to escape. Now it's the enemy's turn!")
      val pause = new PauseTransition(Duration(2000))
      pause.setOnFinished(_ => enemyTurn())
      pause.play()
    }
  }

  def showItems(): Unit = {
    if (!playerTurn || battleActive || gameController.player.cannotMove) {
      return
    }
    gameController.player.endOfTurnEffects()
    battleActive = true
    playerTurn = false
    disableButtons()
    gameController.enterInventoryView()
  }

  def disableButtons(): Unit = {
    attackButton.setDisable(true)
    specialMoveButton.setDisable(true)
    itemButton.setDisable(true)
    waitButton.setDisable(true)
    runButton.setDisable(true)
  }

  def enableButtons(): Unit = {
    attackButton.setDisable(false)
    specialMoveButton.setDisable(false)
    itemButton.setDisable(false)
    waitButton.setDisable(false)
    runButton.setDisable(false)
  }

  def updateBars(): Unit = {
    val playerHealthRatio = gameController.player.health.toDouble / gameController.player.maxHealth.toDouble
    playerHpBar.setProgress(playerHealthRatio)

    val playerMpRatio = gameController.player.mp.toDouble / gameController.player.maxMp.toDouble
    playerMpBar.setProgress(playerMpRatio)

    val enemyHealthRatio = gameController.currentEnemy.map(e => e.health.toDouble / e.maxHealth.toDouble).getOrElse(0.0)
    if (enemyHealthRatio <= 0) {
      enemyHpBar.setProgress(0.0)
    } else {
      enemyHpBar.setProgress(enemyHealthRatio)
    }
  }

  def applyCurseOfImmobilityEffect(): Unit = {
    val currentEnemy = gameController.currentEnemy.getOrElse(return)
    if (currentEnemy.curseOfImmobilityTurnsLeft > 0) {
      currentEnemy.curseOfImmobilityTurnsLeft -= 1
      if (currentEnemy.curseOfImmobilityTurnsLeft == 0) {
        gameController.player.cannotMove = false
      }
    }
  }

  def updateBattleView(message: String, delay: Int): Unit = {
    val pause = new PauseTransition(Duration(delay.toDouble * 1000))
    pause.setOnFinished(_ => messageLabel.setText(message))
    pause.play()
    val currentEnemy = gameController.currentEnemy.getOrElse(return)
    enemyInfoText.setText(s"Level: ${currentEnemy.level} ${currentEnemy.species.name} - HP: ${currentEnemy.health}")
    playerInfoLabel.textProperty().set(s"Level: ${gameController.player.level} Player 1 - HP: ${gameController.player.health}")
  }
}
