package ch.makery.address.controller

import scalafx.scene.{Scene, Parent}
import scalafx.scene.layout.AnchorPane
import scalafxml.core.{FXMLLoader, NoDependencyResolver}
import ch.makery.address.GameApp

class MenuController(resolver: scalafxml.core.ControllerDependencyResolver) {
  def this() = this(NoDependencyResolver)

  def handleStartGame(): Unit = {
    val resource = getClass.getResource("/ch/makery/address/view/TutorialView.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val roots: Parent = new AnchorPane(loader.getRoot[javafx.scene.layout.AnchorPane])
    GameApp.stage.scene = new Scene(roots)
  }

  def handleExitGame(): Unit = {
    GameApp.stage.close()
  }
}
