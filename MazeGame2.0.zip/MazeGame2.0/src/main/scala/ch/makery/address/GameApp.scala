package ch.makery.address

import ch.makery.address.model._
import ch.makery.address.controller._
import scalafx.application.JFXApp
import scalafx.Includes._
import scalafx.scene.Scene
import scalafx.scene.layout.AnchorPane
import scalafxml.core.{FXMLLoader, NoDependencyResolver}

object GameApp extends JFXApp {
  val resource = getClass.getResource("/ch/makery/address/view/MenuView.fxml")
  if (resource == null) {
    throw new RuntimeException("Resource MenuView.fxml not found!")
  }
  val loader = new FXMLLoader(null, NoDependencyResolver)
  loader.setLocation(resource)
  loader.load()
  val roots = loader.getRoot[javafx.scene.layout.AnchorPane]
  stage = new JFXApp.PrimaryStage {
    title = "Maze Game 2.0 - Menu"
    scene = new Scene(roots)
  }

  def startMazeGame(): Unit = {
    val maze = new Maze(32, 20,"/MazeView.tmx")
    maze.generate()
    maze.generateEnemies(50, MazeEnemyPools.maze1Pool)

    val player = new Player(maze.cells(3)(5),"CJ",70,100,30, 5, 0)
    val controller = new GameController(maze, player)

    // Set the stage of your application to the stage of the controller
    stage = controller.stage

    // Show the stage
    stage.show()
    stage.centerOnScreen()
  }
}
