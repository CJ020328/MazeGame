package ch.makery.address.controller

import ch.makery.address.model._
import javafx.fxml.FXMLLoader
import javafx.scene.image.{Image, ImageView}
import scalafx.application.JFXApp.PrimaryStage
import scalafx.scene.Scene
import scalafx.scene.Parent
import scalafx.Includes._
import scalafx.animation.PauseTransition
import scalafx.scene.input.{KeyCode, KeyEvent}
import scalafx.scene.layout.GridPane.sfxGridPane2jfx
import scalafx.util.Duration

class GameController(var maze: Maze, val player: Player) {
  var inBattle: Boolean = false
  var currentEnemy: Option[Enemy] = None // Store the current enemy for the battle
  val playerImage = new Image(getClass.getResource("/image/player.png").toExternalForm())

  // Load MazeView.fxml and get the controller
  val mazeLoader = new FXMLLoader(getClass.getResource("/ch/makery/address/view/MazeView.fxml"))
  val mazeRoot = mazeLoader.load().asInstanceOf[javafx.scene.layout.GridPane]
  val scalaFXMazeRoot = new scalafx.scene.layout.GridPane(mazeRoot)
  val mazeController = mazeLoader.getController[MazeController]
  mazeController.setGameController(this)
  mazeController.setup()


  val battleLoader = new FXMLLoader(getClass.getResource("/ch/makery/address/view/BattleView.fxml"))
  val battleRoot = battleLoader.load().asInstanceOf[javafx.scene.control.SplitPane]
  val scalaFXBattleRoot = new scalafx.scene.control.SplitPane(battleRoot)
  val battleController = battleLoader.getController[BattleController]
  battleController.setGameController(this)

  val inventoryLoader = new FXMLLoader(getClass.getResource("/ch/makery/address/view/InventoryView.fxml"))
  val inventoryRoot = inventoryLoader.load().asInstanceOf[javafx.scene.layout.AnchorPane]
  val scalaFXInventoryRoot = new scalafx.scene.layout.AnchorPane(inventoryRoot)
  val inventoryController = inventoryLoader.getController[InventoryController]
  inventoryController.setGameController(this)

  val mainScene = new Scene(scalaFXMazeRoot)



  val stage = new PrimaryStage {
    title.value = "Maze Game"
    scene = mainScene
  }


  stage.scene().onKeyPressed = (ke: KeyEvent) => {
    mazeController.handleKeyPress(ke)
  }


  def enterBattleView(enemy: Enemy): Unit = {
    inBattle = true
    currentEnemy = Some(enemy)
    val battleLoader = new FXMLLoader(getClass.getResource("/ch/makery/address/view/BattleView.fxml"))
    val battleRoot = battleLoader.load().asInstanceOf[javafx.scene.control.SplitPane]
    val scalaFXBattleRoot = new scalafx.scene.control.SplitPane(battleRoot)
    val battleController = battleLoader.getController[BattleController]
    battleController.setGameController(this)

    mainScene.root = scalaFXBattleRoot
    battleController.startBattle()
  }


  def displayBattleView(): Unit = {
    mainScene.root = scalaFXBattleRoot
    battleController.setupBattleView()
  }




  def exitBattleView(): Unit = {
    inBattle = false
    currentEnemy = None

    // Load MazeView.fxml and get the controller each time you switch to the maze view
    val mazeLoader = new FXMLLoader(getClass.getResource("/ch/makery/address/view/MazeView.fxml"))
    val mazeRoot = mazeLoader.load().asInstanceOf[javafx.scene.layout.GridPane]
    val scalaFXMazeRoot = new scalafx.scene.layout.GridPane(mazeRoot)
    val mazeController = mazeLoader.getController[MazeController]
    mazeController.setGameController(this)

    mazeController.setup()
    mainScene.root = scalaFXMazeRoot
    mainScene.onKeyPressed = (ke: KeyEvent) => mazeController.handleKeyPress(ke)
  }


  def startBattle(enemy: Enemy): Unit = {
    currentEnemy = Some(enemy)
    battleController.startBattle()
  }

  def enterInventoryView(): Unit = {
    mainScene.root = scalaFXInventoryRoot
    inventoryController.updateInventoryList()
    inventoryController.updatePlayerStats()
    mainScene.onKeyPressed = inventoryController.handleKeyPress _
  }

  def exitInventoryView(): Unit = {
    mainScene.root = scalaFXMazeRoot
    mainScene.onKeyPressed = mazeController.handleKeyPress _
    }
}
